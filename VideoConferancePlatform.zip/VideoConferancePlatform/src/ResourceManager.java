import java.awt.*;

public class ResourceManager {
    public static final String RESOURCES_PATH = "src/../resources/";
    public static final Color DEFAULT_BACKGROUND_COLOR = new Color(217, 143, 106);
    public static final String ERROR_MESSAGE = "ERROR MESSAGE: ";

}
