
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.ArrayList;

public class MainMenu extends JPanel {

    public enum ActionType{
        CreateMeetingTriggered,
        JoinMeetingTriggered,
        AccountSettingsTriggered,
        CheckCameraTriggered;

    }
    private ArrayList<ActionListener> aActionListeners;

    private VCPAction jpMeetingCreation;
    private VCPAction jpJoinMeeting;
    private VCPAction jpAccountSettings;
    private VCPAction jpCheckCamera;
    public MainMenu() throws IOException {
        aActionListeners = new ArrayList<>();

        SetupUI();
        MakeListenersConnections();
    }

    private void SetupUI() throws IOException {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel("Video Conference Platform");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setFont(new Font("Lucida Calligraphy", Font.BOLD, 24));

        // Main context
        JPanel jpnMainContext = new JPanel();

        // new meeting
        jpMeetingCreation = new VCPAction(ResourceManager.RESOURCES_PATH + "new_meeting_small.png",
                "Create new meeting");
        jpnMainContext.add("new_meeting", jpMeetingCreation);

        // join meeting
        jpJoinMeeting = new VCPAction(ResourceManager.RESOURCES_PATH + "join_to_meeting_small.png",
                "Join");
        jpnMainContext.add("join_meeting", jpJoinMeeting);

        // account settings
        jpAccountSettings = new VCPAction(ResourceManager.RESOURCES_PATH + "account_settings_small.png",
                "Account settings");
        jpnMainContext.add("account_settings", jpAccountSettings);

        // camera
        jpCheckCamera = new VCPAction(ResourceManager.RESOURCES_PATH + "camera_small.png",
                "Check your look");

        jpnMainContext.add("camera", jpCheckCamera);

        jpnMainContext.setLayout(new GridLayout(2, 2, 20, 5));
        jpnMainContext.setAlignmentX(Component.CENTER_ALIGNMENT);
        jpnMainContext.setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
        jpnMainContext.setMaximumSize(new Dimension(480, 450) );


        add(titleLabel);
        add(Box.createRigidArea(new Dimension(0, 40)));
        add(jpnMainContext);

        setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
    }

    private void MakeListenersConnections(){
        jpMeetingCreation.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                ActionEvent event = new ActionEvent(this, ActionType.CreateMeetingTriggered.ordinal(), "create a meeting");
                emit(event);
            }
        });

        jpJoinMeeting.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                ActionEvent event = new ActionEvent(this, ActionType.JoinMeetingTriggered.ordinal(), "join a meeting");
                emit(event);
            }
        });

        jpCheckCamera.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                ActionEvent event = new ActionEvent(this, ActionType.CheckCameraTriggered.ordinal(), "open camera");
                emit(event);
            }
        });

        jpAccountSettings.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                ActionEvent event = new ActionEvent(this, ActionType.AccountSettingsTriggered.ordinal(), "open account settings");
                emit(event);
            }
        });
    }

    public void AddActionListener(ActionListener l){
        aActionListeners.add(l);
    }

    private void emit(ActionEvent e){
        for (ActionListener l : aActionListeners)
            l.actionPerformed(e);
    }
}
