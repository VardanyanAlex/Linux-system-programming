
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class CheckCameraPage extends JPanel {
    private Camera  oCamera;
    private JButton jbtnBacktoMainMenu;
    public CheckCameraPage(){
        SetupUI();
        SetupButtonConnections();
    }

    private void SetupUI(){
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        setAlignmentX(Component.CENTER_ALIGNMENT);
        setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);

        oCamera = new Camera(null);
        oCamera.setAlignmentX(Component.CENTER_ALIGNMENT);
        oCamera.setAlignmentY(Component.CENTER_ALIGNMENT);
        oCamera.setMaximumSize(new Dimension(600, 480) );
        add(oCamera);

        add(Box.createRigidArea(new Dimension(10,20)));

        jbtnBacktoMainMenu = new JButton("Back to Main Menu");
        jbtnBacktoMainMenu.setAlignmentX(Component.CENTER_ALIGNMENT);
        jbtnBacktoMainMenu.setPreferredSize(new Dimension(70, 30));
        add(jbtnBacktoMainMenu);
    }

    private void SetupButtonConnections(){
        jbtnBacktoMainMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);

                oCamera.stop();
                try {
                    VideoConferencePlatform.getInstance().SetupEntryPage();
                }
                catch (IOException ex){
                    JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong!!!");
                }
            }
        });
    }
}
