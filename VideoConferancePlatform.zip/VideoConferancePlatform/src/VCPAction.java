import GUI_Tools.ImagePanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class VCPAction extends JPanel{
    private ImagePanel  m_icon;
    private JLabel      m_label;

    private static final Color ON_HOVER_COLOR = new Color(245, 215, 179);

    public VCPAction(String iconPath, String label) throws IOException {
        SetupUI(iconPath, label);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(ON_HOVER_COLOR);
                m_icon.setBackground(ON_HOVER_COLOR);

                super.mouseClicked(e);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
                m_icon.setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);

                super.mouseExited(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);
                m_icon.setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);

                super.mouseExited(e);
            }

        });


        setBorder(BorderFactory.createLineBorder(ON_HOVER_COLOR, 2, true));
    }

    private void SetupUI(String iconPath, String label) throws IOException {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(ResourceManager.DEFAULT_BACKGROUND_COLOR);

        m_icon = new ImagePanel(iconPath);
        m_icon.setMaximumSize(new Dimension(200, 150) );
        m_icon.setAlignmentY(Component.CENTER_ALIGNMENT);
        add(m_icon);

        m_label = new JLabel(label);
        m_label.setFont(new Font("Arial", Font.PLAIN, 20));
        m_label.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(m_label);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (g instanceof Graphics2D graphics){
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

//            //Draws the rounded panel with borders.
//            graphics.setColor(getBackground());
//            graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height);//paint background
//            graphics.setColor(getForeground());
//            graphics.drawRoundRect(0, 0, width-1, height, arcs.width, arcs.height);//paint border
        }
    }
}
