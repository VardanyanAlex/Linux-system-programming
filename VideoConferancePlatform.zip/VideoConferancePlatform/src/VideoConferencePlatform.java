
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class VideoConferencePlatform extends JFrame implements ActionListener {

    private MainMenu            jpMainMenu;

    private MeetingPage         jpMeetingPage;
    private JoinMeetingPage     jpJoinMeetingPage;
    private CheckCameraPage     jpCheckCamera;
    private AccountSettingsPage jpAccountSettings;

    private static VideoConferencePlatform oApplication = null;

    private VideoConferencePlatform()  {
        try {
            SetupUI();
            jpMainMenu.AddActionListener(this);
        }
        catch (IOException ex){
            System.out.println(ResourceManager.ERROR_MESSAGE + ex.getMessage());
            System.exit(1);
        }
    }

    public static VideoConferencePlatform getInstance(){
        if (oApplication == null)
            oApplication = new VideoConferencePlatform();

        return oApplication;
    }

    private void SetupUI() throws IOException{
        setTitle("VCP");

        Toolkit tk = Toolkit.getDefaultToolkit();
        int xSize = (int)( tk.getScreenSize().getWidth()  * 0.6);
        int ySize = (int)( tk.getScreenSize().getHeight() * 0.6);

        setSize(xSize, ySize);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        jpMainMenu = new MainMenu();

        setContentPane(jpMainMenu);
    }

    public void SetupEntryPage() throws IOException{
        if (jpMainMenu == null)
            jpMainMenu = new MainMenu();

        setContentPane(jpMainMenu);
    }

    public void JoinMeeting(String sMeetingID) {
        try{
            jpMeetingPage = new MeetingPage();
            jpMeetingPage.JoinMeeting(sMeetingID);
            setContentPane(jpMeetingPage);
            revalidate();
        }
        catch (Exception ex){
            JOptionPane.showMessageDialog(getParent(), "Oops, Smth went wrong, "+ ex.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            MainMenu.ActionType actType = MainMenu.ActionType.values()[e.getID()];

            switch (actType){
                case MainMenu.ActionType.CreateMeetingTriggered:
                    jpMeetingPage = new MeetingPage();
                    jpMeetingPage.CreateMeeting();
                    setContentPane(jpMeetingPage);
                    revalidate();
                    break;
                case MainMenu.ActionType.JoinMeetingTriggered:
                    if (jpJoinMeetingPage == null)
                        jpJoinMeetingPage = new JoinMeetingPage();
                    setContentPane(jpJoinMeetingPage);
                    revalidate();
                    break;
                case MainMenu.ActionType.AccountSettingsTriggered:
                    if (jpAccountSettings == null)
                        jpAccountSettings = new AccountSettingsPage();
                    setContentPane(jpAccountSettings);
                    revalidate();
                    break;
                case MainMenu.ActionType.CheckCameraTriggered:
                    jpCheckCamera = new CheckCameraPage();
                    setContentPane(jpCheckCamera);
                    revalidate();
                    break;
            }
        }
        catch (IOException ex){
            System.out.println("Oops, The operation failed: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VideoConferencePlatform oApp = VideoConferencePlatform.getInstance();
            oApp.setVisible(true);
        });
    }
}
