import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class MeetingEngine {
    public static Runnable ListenMeeting;
    private static DatagramSocket socket;

    /**
     *
     * @return the meeting id.
     * @throws IOException, if failed to open a socket.
     */
    public static String OrganizeMeeting() throws IOException {
        socket = new DatagramSocket();

        Document doc = Document.getInstance();

        String data = "REGISTERAMEETING";
        DatagramPacket dgPacket = new DatagramPacket(data.getBytes(), data.length(), new InetSocketAddress(doc.getHostName(), doc.getHostListeningPort()));
        socket.send(dgPacket);

        byte[] receivedData = new byte[64];
        dgPacket = new DatagramPacket(receivedData, receivedData.length,
                dgPacket.getAddress(), dgPacket.getPort());

        socket.receive(dgPacket);
        String sMessage = new String(dgPacket.getData(), 0, dgPacket.getLength());
        if (!sMessage.startsWith("MEETINGID:") || sMessage.length() != 22)
            return null;

         return sMessage.substring(10, 22);
    }

    public static void SendFrameOverUDP(BufferedImage matFrame, String sMeetingID) {
//        MatOfByte mob = new MatOfByte();
//        Imgcodecs.imencode(".jpg", matFrame, mob);
        byte[] imageData = ("MEETINGID:" + sMeetingID + matFrame.toString()).getBytes();

        Document doc = Document.getInstance();

        try {
            DatagramPacket dgPacket = new DatagramPacket(imageData, imageData.length, new InetSocketAddress(doc.getHostName(), doc.getHostListeningPort()));
            socket.send(dgPacket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Runnable MakeMeetingListener(ICAMHook oHook){
        return new Runnable() {
            @Override
            public void run() {

                try {
                    DatagramSocket socket = new DatagramSocket(6000);
                    while (true) {
                        byte[] buffer = new byte[65507];
                        DatagramPacket dgPacket = new DatagramPacket(buffer, buffer.length);
                        socket.receive(dgPacket);

                        ByteArrayInputStream bytesStream = new ByteArrayInputStream(dgPacket.getData(), 0, dgPacket.getLength());
                        BufferedImage receivedImage = ImageIO.read(bytesStream);
                        oHook.UpdateFrame(receivedImage);
                    }
                } catch (SocketException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }
}
