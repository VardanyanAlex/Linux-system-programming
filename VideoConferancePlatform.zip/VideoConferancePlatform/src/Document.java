public class Document {
    private String  sUsername;

    /** This is the server hostname or the IP address. */
    private String  sHost;
    /** This is the server's listening port number. */
    private int     nPort;
    private static Document doc = null;
    private Document(){
        sUsername = new String();
        sHost = "127.0.0.1";
        nPort = 5000;
    }

    public static Document getInstance(){
        if (doc == null)
            doc = new Document();

        return doc;
    }

    public void setUsername(String sUsername){
        this.sUsername = sUsername;
    }
    public String getUsername(){
        return sUsername;
    }

    public void setHostName(String sHostName){
        this.sHost = sHostName;
    }
    public String getHostName(){
        return sHost;
    }

    public void setHostListeningPort(int port){
        this.nPort = port;
    }
    public int getHostListeningPort(){
        return nPort;
    }
}
