
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.videoio.VideoCapture;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

public class Camera extends JPanel{
    private VideoCapture    oVideoCapture;
    private Mat             matFrame;
    private BufferedImage   bufImage;
    private ICAMHook        oViewer;

    private volatile boolean bCameraStoopped;
    public Camera(ICAMHook oViewer) {
        this.oViewer = oViewer;
        // Load OpenCV native library
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        // Initialize camera
        oVideoCapture = new VideoCapture(0);
        matFrame = new Mat();

        // Start camera feed
        new Thread(this::updateCamera).start();
    }

    private void updateCamera() {
        while (!bCameraStoopped) {
            if (oVideoCapture.read(matFrame)) {
                bufImage = matToBufferedImage(matFrame);
                SwingUtilities.invokeLater(this::repaint);

                if (oViewer != null)
                    oViewer.UpdateFrame(bufImage);
            }
            try {
                Thread.sleep(30);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void stop(){
        bCameraStoopped = true;
        oVideoCapture.release();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (bufImage != null)
            g.drawImage(bufImage, 0, 0, this);
    }

    private BufferedImage matToBufferedImage(Mat mat) {
        // Convert the Mat object to BufferedImage
        int type = BufferedImage.TYPE_BYTE_GRAY;
        if (mat.channels() > 1) {
            type = BufferedImage.TYPE_3BYTE_BGR;
        }
        int bufferSize = mat.channels() * mat.cols() * mat.rows();
        byte[] buffer = new byte[bufferSize];
        mat.get(0, 0, buffer);
        BufferedImage image = new BufferedImage(mat.cols(), mat.rows(), type);
        final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(buffer, 0, targetPixels, 0, buffer.length);
        return image;
    }
}