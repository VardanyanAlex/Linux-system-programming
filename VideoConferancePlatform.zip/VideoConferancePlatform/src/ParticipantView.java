
import org.opencv.core.Core;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class ParticipantView extends JPanel implements ICAMHook{
    private BufferedImage   bufImage;

    public ParticipantView() {
        // Load OpenCV native library
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        new Thread(this::updatePane).start();
    }

    @Override
    public  void UpdateFrame(BufferedImage bufImage){
        this.bufImage = bufImage;
    }

    private void updatePane() {
        if(bufImage == null)
            return;

        SwingUtilities.invokeLater(this::repaint);

        try {
            Thread.sleep(30);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (bufImage != null)
            g.drawImage(bufImage, 0, 0, this);
    }
}
